# Text File
# AUTHOR:   manawasp
# MAIL:     clovis.kyndt@gmail.com
# FILE:     README.md
# ROLE:     TODO (some explanation)
# CREATED:  2015-05-15 20:08:52
# MODIFIED: 2015-05-15 20:09:31

restore

step1:
cp `pictures` dir to `public`

step2:
mongorestore
